# Notion Source Links

- [不在世界中心的我们](https://cotton-durian-08d.notion.site/20aabfd62fbf80929a1bd518c600cbb6)
- [君子非人](https://cotton-durian-08d.notion.site/203abfd62fbf80abadd9d062b5ef759e)
- [Qualia结构行为](https://cotton-durian-08d.notion.site/1fdabfd62fbf80d48e04f4960b8b94b1)
